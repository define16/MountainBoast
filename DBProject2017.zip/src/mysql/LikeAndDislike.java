package mysql;

public class LikeAndDislike {
	private String code;
	private int like;
	private int dislike;
	private int switch_like;
	private int switch_dislike;
	
	public LikeAndDislike() {

	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public int getDislike() {
		return dislike;
	}
	public void setDislike(int dislike) {
		this.dislike = dislike;
	}
	public int getSwitch_like() {
		return switch_like;
	}
	public void setSwitch_like(int switch_like) {
		this.switch_like = switch_like;
	}
	public int getSwitch_dislike() {
		return switch_dislike;
	}
	public void setSwitch_dislike(int switch_dislike) {
		this.switch_dislike = switch_dislike;
	}

	
	
	
}
