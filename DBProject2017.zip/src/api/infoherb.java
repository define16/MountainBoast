package api;

public class infoherb {
	
	private String name;
	private String plantClsscNm;
	private String mclltSfrmdNm;
	private String plantFamlNm;
	private String plantEclgDscrt;
	private String mclltDistrDscrt;
	private String useway;
	private String eatway;
	private String image1;
	private String image2;
	private String image3;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlantClsscNm() {
		return plantClsscNm;
	}
	public void setPlantClsscNm(String plantClsscNm) {
		this.plantClsscNm = plantClsscNm;
	}
	public String getMclltSfrmdNm() {
		return mclltSfrmdNm;
	}
	public void setMclltSfrmdNm(String mclltSfrmdNm) {
		this.mclltSfrmdNm = mclltSfrmdNm;
	}
	public String getPlantFamlNm() {
		return plantFamlNm;
	}
	public void setPlantFamlNm(String plantFamlNm) {
		this.plantFamlNm = plantFamlNm;
	}
	public String getPlantEclgDscrt() {
		return plantEclgDscrt;
	}
	public void setPlantEclgDscrt(String plantEclgDscrt) {
		this.plantEclgDscrt = plantEclgDscrt;
	}
	public String getMclltDistrDscrt() {
		return mclltDistrDscrt;
	}
	public void setMclltDistrDscrt(String mclltDistrDscrt) {
		this.mclltDistrDscrt = mclltDistrDscrt;
	}
	public String getUseway() {
		return useway;
	}
	public void setUseway(String useway) {
		this.useway = useway;
	}
	public String getEatway() {
		return eatway;
	}
	public void setEatway(String eatway) {
		this.eatway = eatway;
	}
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	public String getImage3() {
		return image3;
	}
	public void setImage3(String image3) {
		this.image3 = image3;
	}


}
