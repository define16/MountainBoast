package webProject2017;

public class bookmark {
	//String filename1 = "D:\\Programing Folder\Web\University\webProject2017\WebContent\UI\files";
	//String filename2 = "D:\\Programing Folder\Web\University\webProject2017\WebContent\UI\files";
}
